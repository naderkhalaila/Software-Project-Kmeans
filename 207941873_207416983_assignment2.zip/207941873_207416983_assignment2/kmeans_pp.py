# kmeans pp.py: The “glue” and the main entry point of your assignment. It will contain all of the
# command-line argument interface, reading the data, the Numpy K-means++ implementation,
# the interface with your C extension and outputting the results.

import argparse
import sys
from numpy.core.records import array
import pandas as pd
import numpy as np
from pandas.io.parsers import read_csv
import mykmeanssp

def main(K, MAX_ITER, file_name_1, file_name_2):
    data = read_data(file_name_1, file_name_2) #
    #initiale_indices are the list of indices as given form the user
    initial_indices = data.iloc[:, :1]
    initial_indices = initial_indices.to_numpy()
    initial_indices = np.array(initial_indices)
    data = data.iloc[:, 1:] 
    data = data.to_numpy()
    data = np.array(data)
    d = data.shape[1] 
    N = data.shape[0]
    if(K >= N):
        print("Invalid Input!")
        return -1
    centroids = initialize_centroids(data,initial_indices, K, d, N)
    data_list = data.tolist()
    centorids_list = centroids.tolist()
    centroids =  mykmeanssp.fit(data_list, centorids_list, N, d, K, MAX_ITER)
    centroids = np.array(centroids)
    centroids = np.round(centroids, decimals = 4)
    print_centroids(centroids)
    return None

def read_data(file_name_1, file_name_2): 
    df1 = pd.read_csv(file_name_1, header=None)
    df2 = pd.read_csv(file_name_2, header=None)
    data = pd.merge(df1, df2, on=0)
    data = data.sort_values(by=[0])
    return data

#initializes the centroids using kmean++ algorithm
def initialize_centroids(data,initiale_indices, K, d, N):
    indices = np.ndarray(K, int)
    centroids = np.ndarray((K,d), float)
    np.random.seed(0)
    index = np.random.choice(N)
    indices[0] = initiale_indices[index]
    centroids[0] = data[index]
    Z = 1
    D = np.zeros((N))
    P = np.zeros((N))
    while Z<K:
        for i in range(0, N):
            min = float("inf")
            for j in range(0, Z):
                distance = np.sum(np.power(data[i] - centroids[j], 2))
                if(distance<min):
                    min = distance
            D[i] = min
        sum_D = np.sum(D)
        P = np.divide(D, sum_D)
        index = np.random.choice(N, p=P)
        indices[Z] = initiale_indices[index]
        centroids[Z] = data[index]
        Z+=1
    print(','.join(str(i) for i in indices), flush=True) 
    return centroids

def print_centroids(centroids):
    for i in range (len(centroids)):
        centroid = centroids[i]
        for j in range(len(centroid)):
            if(j != (len(centroid)-1)):
                print(str(centroid[j])+ ",", end="")
            else:
                if(i==len(centroids)-1):
                    print(centroid[j], end="")
                else:
                    print(centroid[j])

def start(): #gets arguments and starts the algorethim.
    parser = argparse.ArgumentParser()
    parser.add_argument("K", type=int, help="K is the number of clusters")
    parser.add_argument("MAX_ITER", nargs="?", type=int, help="The maximum number of the K-means algorithm")
    parser.add_argument("file_name_1", type=str, help="The path to file 1 which contains N observations")
    parser.add_argument("file_name_2", type=str, help="The path to file 2 which contains N observations")
    args = parser.parse_args()
    K = args.K 
    MAX_ITER = args.MAX_ITER
    file_name_1 = args.file_name_1
    file_name_2 = args.file_name_2
    #assertions
    if MAX_ITER == None:
    	MAX_ITER = 300
    if MAX_ITER < 1:
        print("Invalid Input!")
        return -1
    if K == None:
        print("Invalid Input!")
        return -1
    if(K<1):
        print("Invalid Input!")
        return -1
    if (file_name_1 or file_name_2) == None:
        print("Invalid Input!")
        return -1
    main(K, MAX_ITER, file_name_1, file_name_2)

start()