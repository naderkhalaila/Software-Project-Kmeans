#include <Python.h>
#define PY_SSIZE_T_CLEANS

/* functions declarations */
static PyObject* kmeans_capi(PyObject *self, PyObject *args);
static double **parse_arrays(PyObject* _list, int num_row, int num_col);
static PyObject *pseudo_main(PyObject* Py_data, PyObject* Py_centroids, int N, int d, int K, int MAX_ITER); //static?
int assign(double vec[], double** centroids, int K, int d);
double calculate_distance(double vec1[], double vec2[], int d);
void update_centroids(double** cSum, int* cNum, double** centroids, int K, int d);
void sum_vec(double vec1[], double vec2[], int d);
void sub_vec(double vec1[], double vec2[], int d);
void free_data(int N, int K, double** data,double** centroids,double** cSum,int* cNum,int* data_index);


/* ------------------ C API ------------------ */

/* the wrapping function for the pseudo_main - parses PyObjects */
static PyObject* kmeans_capi(PyObject *self, PyObject *args){
    PyObject *data, *centroids;
    int N, d, K, MAX_ITER;
   if(!PyArg_ParseTuple(args, "OOiiii", &data, &centroids, &N, &d, &K, &MAX_ITER)){
       return NULL;
   }
   return Py_BuildValue("O", pseudo_main(data, centroids, N, d, K, MAX_ITER));
}

/* functino that parses the data and puts them in arrays */
static double **parse_arrays(PyObject* _list, int num_row, int num_col) {
    int i, j;
    Py_ssize_t Py_i, Py_j;
    double **parsed_data;
    parsed_data = malloc(num_row * sizeof(double*));
    assert(parsed_data!=NULL);
    PyObject* item; PyObject* num;
    for (i = 0; i < num_row; i++) {
        Py_i = (Py_ssize_t)i;
        parsed_data[Py_i] = malloc(num_col * sizeof(double));
        assert(parsed_data[Py_i]!=NULL);
        item = PyList_GetItem(_list, Py_i);
        if (!PyList_Check(item)){ /* Skips non-lists */
            continue;
        }
        for (j = 0; j < num_col; j++) {
            Py_j = (Py_ssize_t)j;
            num = PyList_GetItem(item, Py_j);
            if (!PyFloat_Check(num)) continue; /* Skips non-floats */
            parsed_data[Py_i][Py_j] = PyFloat_AsDouble(num);
        }
    }return parsed_data;
}

/* this array tells python what methods this module has */
static PyMethodDef capiMethods[] = {
                                    {"fit",
                                    (PyCFunction) kmeans_capi,
                                    METH_VARARGS,
                                    PyDoc_STR("calculates the centroids using kmeans algorithm")},
                                    {NULL, NULL, 0, NULL}
        };  

/* This struct initiates the module using the above definition. */
static struct PyModuleDef moduledef = {
    PyModuleDef_HEAD_INIT,  
    "mykmeanssp",           //name of module
    NULL,                   //module documentation
    -1,                     //size of per-interpreter
    capiMethods
};

/* Module Creation */
PyMODINIT_FUNC
PyInit_mykmeanssp(void) {
    PyObject *m;
    m = PyModule_Create(&moduledef);
    if (!m) {
        return NULL;
    }
    return m;
}

/* initializing data and running the algorithm */
static PyObject *pseudo_main(PyObject* Py_data, PyObject* Py_centroids, int N, int d, int K, int MAX_ITER){
    PyObject *lst_centroids, *vec, *num;
    double ** data, **centroids, **cSum;
    int counter=0, changed=1, i, j, *cNum, *data_index;
    /* initialising centroids, data, cSum, cNum, data_index*/
    data = parse_arrays(Py_data, N, d);
    centroids = parse_arrays(Py_centroids, K, d);
    cNum = (int*)calloc(K,sizeof(int));
    assert(cNum!=NULL);
    cSum =(double**)malloc(K*sizeof(double*));
    assert(cSum!=NULL);
    for(i=0; i<K; i++){
        cSum[i] =(double*)calloc(d,sizeof(double));
        assert(cSum[i]!=NULL);
   }
   data_index = (int*)malloc(N*sizeof(int));
   assert(data_index!=NULL);
    /* kmeans Algorithm */
   for(i=0; i<N; i++){
       data_index[i] = -1;
   }
    while((counter < MAX_ITER) & changed){
       changed = 0;
       counter += 1;
       for(i=0; i<N; i++){
           int index = assign(data[i], centroids, K, d);
           if(data_index[i] != index){
               changed = 1;
               cNum[index] += 1;
               sum_vec(cSum[index], data[i], d);
               if(data_index[i] != -1){
                   cNum[data_index[i]] -= 1;
                   sub_vec(cSum[data_index[i]], data[i], d);
               }
           }data_index[i] = index;
       }update_centroids(cSum, cNum, centroids, K, d);  
   }

   lst_centroids = PyList_New(K);
   if (!lst_centroids){
            return NULL;
        }
   for(i=0; i<K; i++){
       vec = PyList_New(d);
        if (!vec){
            return NULL;
            }
        for (j = 0; j < d; j++) {
            num = PyFloat_FromDouble(centroids[i][j]);
            if (!num) {
                Py_DECREF(vec);
                return NULL;
            }PyList_SET_ITEM(vec, j, num); 
        }PyList_SET_ITEM(lst_centroids, i, vec); 
    }
    free_data(N,K,data,centroids,cSum,cNum,data_index);
    return lst_centroids; 
}

/* ------------------ HW1 FUNCTIONS ------------------*/

int assign(double vec[], double** centroids, int K, int d){
    double min = 0;
    int i, centroid_index = -1;
    for(i=0; i<K; i++){
        double new_dis = calculate_distance(vec, centroids[i], d);
        if((new_dis < min) || (centroid_index == -1)){
            min = new_dis;
            centroid_index = i;
        }
    }return centroid_index;
}

double calculate_distance(double vec1[], double vec2[], int d){
    double sum = 0;
    int i;
    for(i=0; i<d; i++){
        sum += (vec1[i]-vec2[i])*(vec1[i]-vec2[i]);
    }return sum;
}

void update_centroids(double** cSum, int* cNum, double** centroids, int K, int d){
    int i, j;
    for(i=0; i<K; i++){
        double * centroid = centroids[i];
        for(j=0; j<d; j++){
            if(cNum[i] != 0){
                centroid[j] = cSum[i][j]/cNum[i];
            }
        }
    }
}

void sum_vec(double vec1[], double vec2[], int d){
    int i;
    for(i=0; i<d; i++){
        vec1[i] += vec2[i];
    }
}

void sub_vec(double vec1[], double vec2[], int d){
    int i;
    for(i=0; i<d; i++){
        vec1[i] -= vec2[i];
    }
}

void free_data(int N, int K, double** data,double** centroids,double** cSum,int* cNum,int* data_index){
    int i;
    for(i=0 ; i<N ; i++){
        free(data[i]);
    }free(data);
    for(i=0; i<K; i++){
        free(centroids[i]);
        free(cSum[i]);
    }
    free(centroids);
    free(cSum);
    free(cNum);
    free(data_index);
}